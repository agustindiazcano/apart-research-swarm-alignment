Open index.html in a browser and press Play (Space). Narration plays from narration.wav. Options: ?audio=0 mutes it.
